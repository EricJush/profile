// Add any interactive features here
document.addEventListener('DOMContentLoaded', () => {
    console.log("Portfolio website loaded successfully.");
});